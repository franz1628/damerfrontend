import { Component } from '@angular/core';

@Component({
  selector: 'app-mantenimiento-layout-footer',
  templateUrl: './mantenimiento-layout-footer.component.html'
})
export class MantenimientoLayoutFooterComponent {

}
