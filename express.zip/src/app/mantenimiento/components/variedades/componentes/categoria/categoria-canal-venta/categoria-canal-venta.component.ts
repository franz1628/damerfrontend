import { Component } from '@angular/core';

@Component({
  selector: 'app-categoria-canal-venta',
  templateUrl: './categoria-canal-venta.component.html'
})
export class CategoriaCanalVentaComponent {

}
