import { Component } from '@angular/core';

@Component({
  selector: 'app-categoria-exhibidores',
  templateUrl: './categoria-exhibidores.component.html'
})
export class CategoriaExhibidoresComponent {

}
