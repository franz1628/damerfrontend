import { Component } from '@angular/core';

@Component({
  selector: 'app-negocio-list',
  templateUrl: './negocio-list.component.html'
})
export class NegocioListComponent {

}
