export interface Pais {
    id: number ,
    descripcion: string,
    estado: number
}

export const PaisInit: Pais = {
    id : 0 ,
    descripcion : '',
    estado: 1
  };
