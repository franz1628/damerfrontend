import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-tablas',
  templateUrl: './layout-tablas.component.html',
  styles: ``
})
export class LayoutTablasComponent {

}
