import { Component } from '@angular/core';

@Component({
  selector: 'app-contrato',
  templateUrl: './contrato.component.html'
})
export class ContratoComponent {

}
