export interface TipoTipoCambio {
    id: number,
    descripcion: string


}
export const TipoTipoCambioInit: TipoTipoCambio = {
    id: 0,
    descripcion: ""
};