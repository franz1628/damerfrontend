
export interface EstadoContrato {
    id: number,
    descripcion:string
    
}
export const EstadoContratoInit: EstadoContrato = {
    id: 0,
    descripcion:'' 
};