export interface ContratoVariable {
    id: number,
    idContrato: number,
    idVariable: number,
}
export const ContratoVariableInit: ContratoVariable = {
    id: 0,
    idContrato: 0,
    idVariable: 0,
};