export interface ContratoUnidadVenta {
    id: number,
    idContrato: number,
    idUnidadVenta: number,
}
export const ContratoUnidadVentaInit: ContratoUnidadVenta = {
    id: 0,
    idContrato: 0,
    idUnidadVenta: 0,
};