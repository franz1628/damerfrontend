export interface TipoZona {
    id: number,
    descripcion: string,
}
export const TipoZonaInit: TipoZona = {
    id: 0,
    descripcion: '',
};