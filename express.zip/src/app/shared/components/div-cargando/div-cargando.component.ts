import { Component } from '@angular/core';

@Component({
  selector: 'app-div-cargando',
  templateUrl: './div-cargando.component.html'
})
export class DivCargandoComponent {

}
