export interface Response {
    data: any,
    state: number,
    message: string
}