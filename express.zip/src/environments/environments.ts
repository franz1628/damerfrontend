export const environments = {
    baseUrl: 'http://localhost:8080/',
    imgNotFound : 'uploads/sku/img/noimagen.png'
}